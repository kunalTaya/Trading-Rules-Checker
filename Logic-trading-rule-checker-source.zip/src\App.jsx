import { useEffect, useMemo, useRef, useState } from "react";

const FALLBACK = {
  rules: [
    { id: "trend", text: "Trend alignment checked", checked: false },
    { id: "risk-reward", text: "Risk/Reward ratio >= 1:2", checked: false },
    { id: "levels", text: "Support/Resistance level respected", checked: false },
    { id: "news", text: "News event checked", checked: false }
  ],
  colors: { fill: "#142522", text: "#e5fff8", line: "#355851", light: "#62f5c7" }
};

const previewBridge = {
  async loadPreferences() {
    const saved = window.localStorage.getItem("logic-trading-rules");
    return saved ? JSON.parse(saved) : FALLBACK;
  },
  async savePreferences(state) {
    window.localStorage.setItem("logic-trading-rules", JSON.stringify(state));
  },
  setExpanded() {},
  moveWindow() {},
  quit() {}
};

const bridge = window.logic || previewBridge;

const COLOR_CONTROLS = [
  ["fill", "Badge fill"],
  ["text", "Badge text"],
  ["line", "Outer line"],
  ["light", "Running light"]
];

export default function App() {
  const [state, setState] = useState(FALLBACK);
  const [ready, setReady] = useState(false);
  const [expanded, setExpanded] = useState(false);
  const [editing, setEditing] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [newRule, setNewRule] = useState("");
  const drag = useRef(null);
  const dragged = useRef(false);
  useEffect(() => {
    let active = true;
    bridge.loadPreferences()
      .then((loaded) => {
        if (active && loaded) setState(loaded);
      })
      .catch((error) => {
        console.error("Unable to load saved trading rules.", error);
      })
      .finally(() => {
        if (active) setReady(true);
      });
    return () => { active = false; };
  }, []);

  useEffect(() => {
    if (!ready) return undefined;
    const timer = window.setTimeout(() => {
      bridge.savePreferences(state).catch((error) => {
        console.error("Unable to save trading rules.", error);
      });
    }, 180);
    return () => window.clearTimeout(timer);
  }, [ready, state]);

  useEffect(() => {
    bridge.setExpanded(expanded);
  }, [expanded]);

  const completed = useMemo(() => state.rules.filter((rule) => rule.checked).length, [state.rules]);
  const progress = state.rules.length ? Math.round((completed / state.rules.length) * 100) : 0;

  function updateRule(id, updates) {
    setState((current) => ({
      ...current,
      rules: current.rules.map((rule) => rule.id === id ? { ...rule, ...updates } : rule)
    }));
  }

  function addRule(event) {
    event.preventDefault();
    const text = newRule.trim();
    if (!text) return;
    setState((current) => ({
      ...current,
      rules: [...current.rules, { id: window.crypto.randomUUID(), text, checked: false }]
    }));
    setNewRule("");
    setEditing(false);
  }

  function removeRule(id) {
    setState((current) => ({ ...current, rules: current.rules.filter((rule) => rule.id !== id) }));
  }

  function onBadgePointerDown(event) {
    if (event.button !== 0) return;
    drag.current = { x: event.screenX, y: event.screenY };
    dragged.current = false;
    event.currentTarget.setPointerCapture(event.pointerId);
  }

  function onBadgePointerMove(event) {
    if (!drag.current || !(event.buttons & 1)) return;
    const dx = event.screenX - drag.current.x;
    const dy = event.screenY - drag.current.y;
    if (!dragged.current && Math.hypot(dx, dy) < 4) return;
    dragged.current = true;
    drag.current = { x: event.screenX, y: event.screenY };
    bridge.moveWindow(dx, dy);
  }

  function onBadgePointerUp() {
    drag.current = null;
  }

  function toggleBadge() {
    if (dragged.current) {
      dragged.current = false;
      return;
    }
    setExpanded((value) => !value);
  }

  function editRule(id, text) {
    updateRule(id, { text });
  }

  const badgeStyle = {
    "--badge-fill": state.colors.fill,
    "--badge-text": state.colors.text,
    "--badge-line": state.colors.line,
    "--running-light": state.colors.light
  };

  return (
    <main className={`shell ${expanded ? "is-expanded" : ""}`} style={badgeStyle}>
      <button
        className="badge"
        type="button"
        aria-label={expanded ? "Close trading rule checklist. Drag to move." : "Open trading rule checklist. Drag to move."}
        aria-expanded={expanded}
        onPointerDown={onBadgePointerDown}
        onPointerMove={onBadgePointerMove}
        onPointerUp={onBadgePointerUp}
        onPointerCancel={onBadgePointerUp}
        onClick={toggleBadge}
      >
        <span className="badge-inner">
          <span className="badge-mark" aria-hidden="true"><i /><i /><i /></span>
          <span className="badge-word">Logic</span>
        </span>
      </button>

      {expanded && (
        <section className="panel" aria-label="Trading rule checklist">
          <header className="panel-header">
            <div>
              <p className="eyebrow">TRADE WITH INTENTION</p>
              <h1>Before you enter</h1>
            </div>
            <button
              className="icon-button close-button"
              type="button"
              aria-label="Close checklist"
              onClick={() => setExpanded(false)}
            >×</button>
          </header>

          <div className="progress-card" aria-live="polite">
            <div className="progress-copy">
              <span className="progress-label">SESSION READINESS</span>
              <span className="progress-count">{completed}<span> / {state.rules.length}</span></span>
            </div>
            <div className="progress-track" role="progressbar" aria-label="Rules completed" aria-valuemin="0" aria-valuemax={Math.max(1, state.rules.length)} aria-valuenow={completed}>
              <span style={{ width: `${progress}%` }} />
            </div>
            <p className="progress-note">{state.rules.length > 0 && completed === state.rules.length
              ? "You're clear. Trust your process."
              : "A good trade starts before the chart."}</p>
          </div>

          <div className="list-heading">
            <h2>Your checklist</h2>
            <button className="text-button" type="button" onClick={() => setEditing((value) => !value)}>
              {editing ? "Done" : "Edit rules"}
            </button>
          </div>

          <ul className="rule-list">
            {state.rules.map((rule, index) => (
              <li className={`rule-row ${rule.checked ? "is-checked" : ""} ${editing ? "is-editing" : ""}`} key={rule.id}>
                <label className={`rule-label ${editing ? "check-only" : ""}`}>
                  <input
                    type="checkbox"
                    checked={rule.checked}
                    aria-label={`Mark rule ${index + 1} complete`}
                    onChange={(event) => updateRule(rule.id, { checked: event.target.checked })}
                  />
                  <span className="custom-check" aria-hidden="true"><svg viewBox="0 0 16 16"><path d="m3.3 8.2 3 3.1 6.5-6.6" /></svg></span>
                  {!editing && (
                    <span className="rule-text">{rule.text}</span>
                  )}
                </label>
                {editing && (
                  <input
                    className="rule-edit"
                    aria-label={`Edit rule ${index + 1}`}
                    value={rule.text}
                    maxLength={180}
                    onChange={(event) => editRule(rule.id, event.target.value)}
                  />
                )}
                {editing && (
                  <button className="icon-button remove-button" type="button" aria-label={`Remove ${rule.text || "rule"}`} onClick={() => removeRule(rule.id)}>−</button>
                )}
              </li>
            ))}
          </ul>

          {editing && (
            <form className="add-rule" onSubmit={addRule}>
              <input
                aria-label="New trading rule"
                placeholder="Add a personal rule…"
                value={newRule}
                maxLength={180}
                onChange={(event) => setNewRule(event.target.value)}
              />
              <button type="submit" aria-label="Add rule" disabled={!newRule.trim()}>+</button>
            </form>
          )}

          <div className="settings-wrap">
            <button className="settings-toggle" type="button" aria-expanded={settingsOpen} onClick={() => setSettingsOpen((value) => !value)}>
              <span className="settings-icon" aria-hidden="true">◌</span>
              <span>Badge appearance</span>
              <span className="settings-chevron" aria-hidden="true">{settingsOpen ? "−" : "+"}</span>
            </button>
            {settingsOpen && (
              <div className="color-settings">
                {COLOR_CONTROLS.map(([key, label]) => (
                  <label className="color-setting" key={key}>
                    <span>{label}</span>
                    <span className="color-value">
                      <input
                        type="color"
                        aria-label={label}
                        value={state.colors[key]}
                        onChange={(event) => setState((current) => ({
                          ...current,
                          colors: { ...current.colors, [key]: event.target.value }
                        }))}
                      />
                      <code>{state.colors[key].toUpperCase()}</code>
                    </span>
                  </label>
                ))}
              </div>
            )}
          </div>

          <footer className="panel-footer">
            <span className="status-dot" />
            <span>Built for better decisions</span>
            <button className="quit-button" type="button" onClick={() => bridge.quit()}>Quit app</button>
            <span className="footer-version">LOGIC / 01</span>
          </footer>
        </section>
      )}
    </main>
  );
}
