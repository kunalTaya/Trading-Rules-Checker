const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("logic", Object.freeze({
  loadPreferences: () => ipcRenderer.invoke("preferences:load"),
  savePreferences: (state) => ipcRenderer.invoke("preferences:save", state),
  setExpanded: (expanded) => ipcRenderer.send("window:set-expanded", expanded),
  moveWindow: (x, y) => ipcRenderer.send("window:move", { x, y }),
  quit: () => ipcRenderer.send("app:quit")
}));
