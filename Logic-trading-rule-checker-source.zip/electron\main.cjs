const { app, BrowserWindow, ipcMain, screen } = require("electron");
const fs = require("node:fs");
const path = require("node:path");

const COLLAPSED = { width: 124, height: 110 };
const EXPANDED = { width: 416, height: 690 };
const HEX_COLOR = /^#[0-9a-fA-F]{6}$/;
const DEFAULTS = {
  rules: [
    { id: "trend", text: "Trend alignment checked", checked: false },
    { id: "risk-reward", text: "Risk/Reward ratio >= 1:2", checked: false },
    { id: "levels", text: "Support/Resistance level respected", checked: false },
    { id: "news", text: "News event checked", checked: false }
  ],
  colors: {
    fill: "#142522",
    text: "#e5fff8",
    line: "#355851",
    light: "#62f5c7"
  }
};

let mainWindow;
let expanded = false;
let statePath;

function sanitizeState(input) {
  const safeColors = { ...DEFAULTS.colors };
  if (input && input.colors && typeof input.colors === "object") {
    for (const key of Object.keys(safeColors)) {
      if (typeof input.colors[key] === "string" && HEX_COLOR.test(input.colors[key])) {
        safeColors[key] = input.colors[key];
      }
    }
  }

  const rules = Array.isArray(input && input.rules)
    ? input.rules.slice(0, 100).map((rule, index) => ({
        id: typeof rule.id === "string" && rule.id.length <= 100
          ? rule.id
          : `rule-${index}`,
        text: typeof rule.text === "string" ? rule.text.slice(0, 180) : "",
        checked: rule.checked === true
      }))
    : DEFAULTS.rules;

  return { rules, colors: safeColors };
}

function readState() {
  try {
    return sanitizeState(JSON.parse(fs.readFileSync(statePath, "utf8")));
  } catch (error) {
    if (error.code !== "ENOENT") {
      console.error("Unable to read saved trading rules; using defaults.", error);
    }
    return sanitizeState(DEFAULTS);
  }
}

function writeState(input) {
  const safeState = sanitizeState(input);
  const temporaryPath = `${statePath}.tmp`;
  fs.writeFileSync(temporaryPath, JSON.stringify(safeState, null, 2), "utf8");
  fs.renameSync(temporaryPath, statePath);
  return safeState;
}

function clampWindowBounds(x, y, size) {
  const display = screen.getDisplayMatching({ x, y, width: size.width, height: size.height });
  const area = display.workArea;
  return {
    x: Math.max(area.x, Math.min(x, area.x + area.width - size.width)),
    y: Math.max(area.y, Math.min(y, area.y + area.height - size.height))
  };
}

function resizeWindow(isExpanded) {
  if (!mainWindow || mainWindow.isDestroyed()) return;
  expanded = isExpanded;
  const size = expanded ? EXPANDED : COLLAPSED;
  const bounds = mainWindow.getBounds();
  const position = clampWindowBounds(bounds.x, bounds.y, size);
  mainWindow.setBounds({ ...position, ...size }, true);
}

function createWindow() {
  const initialPosition = clampWindowBounds(
    screen.getPrimaryDisplay().workArea.x + 28,
    screen.getPrimaryDisplay().workArea.y + 120,
    COLLAPSED
  );
  mainWindow = new BrowserWindow({
    ...initialPosition,
    ...COLLAPSED,
    frame: false,
    transparent: true,
    resizable: false,
    show: false,
    alwaysOnTop: true,
    skipTaskbar: true,
    hasShadow: false,
    backgroundColor: "#00000000",
    webPreferences: {
      preload: path.join(__dirname, "preload.cjs"),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    }
  });
  mainWindow.setAlwaysOnTop(true, "floating");
  mainWindow.setVisibleOnAllWorkspaces(true, { visibleOnFullScreen: true });
  mainWindow.once("ready-to-show", () => mainWindow.show());

  const devServerUrl = process.env.VITE_DEV_SERVER_URL;
  if (devServerUrl) {
    mainWindow.loadURL(devServerUrl);
  } else {
    mainWindow.loadFile(path.join(__dirname, "..", "dist", "ui", "index.html"));
  }
}

app.whenReady().then(() => {
  statePath = path.join(app.getPath("userData"), "trading-rules.json");
  ipcMain.handle("preferences:load", () => readState());
  ipcMain.handle("preferences:save", (_event, state) => writeState(state));
  ipcMain.on("window:set-expanded", (_event, value) => {
    if (typeof value === "boolean") resizeWindow(value);
  });
  ipcMain.on("app:quit", () => app.quit());
  ipcMain.on("window:move", (_event, delta) => {
    if (!mainWindow || mainWindow.isDestroyed() || !delta) return;
    const dx = Number.isFinite(delta.x) ? Math.max(-100, Math.min(100, Math.round(delta.x))) : 0;
    const dy = Number.isFinite(delta.y) ? Math.max(-100, Math.min(100, Math.round(delta.y))) : 0;
    if (dx === 0 && dy === 0) return;
    const bounds = mainWindow.getBounds();
    const position = clampWindowBounds(bounds.x + dx, bounds.y + dy, expanded ? EXPANDED : COLLAPSED);
    mainWindow.setPosition(position.x, position.y, false);
  });

  createWindow();
  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
